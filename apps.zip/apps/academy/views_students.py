import logging
from django.views.generic import TemplateView
from django.shortcuts import redirect, get_object_or_404, render
from django.contrib import messages
from django.contrib.auth.mixins import PermissionRequiredMixin
from web_project import TemplateLayout
from .models import UserMhs, UserDosen, Course, CourseParticipant, CourseAgenda, CourseMaterial, CourseAssignment, CourseAnnouncement, StudentMaterialProgress, StudentAssignmentSubmission, CourseAttendance, CourseQuiz, StudentQuizAttempt, StudentQuizAnswer, QuizQuestion, QuizOption, CourseParticipant, CourseGroupMember,  Book, BookCategory
from .forms_mhs import MhsProfileForm  # Pastikan import form Anda
from django.contrib.auth.mixins import LoginRequiredMixin
from .decorators_students import StudentsRequiredMixin
from django.utils import timezone
from django.db.models import Sum
from django.db.models import Q, F, Count

class AcademyView(TemplateView):
    # Predefined function
    def get_context_data(self, **kwargs):
        # A function to init the global layout. It is defined in web_project/__init__.py file
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))

        return context
    
class UsersView(PermissionRequiredMixin, TemplateView):
    permission_required = ("user.view_user", "user.delete_user", "user.change_user", "user.add_user")

    def get_context_data(self, **kwargs):
        context = TemplateLayout.init(self, super().get_context_data(**kwargs))
        return context

# --- View Edit Profile Mahasiswa (BARU) ---
class UserProfileView(StudentsRequiredMixin, UsersView):
    template_name = "students/profile.html"
    permission_required = [] 

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        usermhs = get_object_or_404(UserMhs, nim=self.request.user)

        if 'form' not in kwargs:
            kwargs['form'] = MhsProfileForm(instance=usermhs)
        
        # 4. Update context
        context.update({
            "title": "Profile",
            "heading": "Edit Profile",
            "usermhs": usermhs,
            "photo": usermhs.photo,
            "form": kwargs['form'], # Masukkan form ke context
        })
        
        return context

    def post(self, request, *args, **kwargs):
        usermhs = get_object_or_404(UserMhs, nim=request.user)
        form = MhsProfileForm(request.POST, request.FILES, instance=usermhs)
        
        if form.is_valid():
            form.save()
            messages.success(request, 'Profil Anda berhasil diperbarui!')
            return redirect('profile') # Sesuaikan dengan nama URL Anda
        else:
            messages.error(request, 'Gagal Memproses, pastikan semua isian sesuai format')
            return self.render_to_response(self.get_context_data(form=form))
        

class StudentCourseListView(StudentsRequiredMixin, UsersView):
    template_name = "students/app_academy_course.html"
    permission_required = [] 

    def dispatch(self, request, *args, **kwargs):
        try:
            if not request.user.usermhs.photo:
                messages.warning(request, "Maaf, Anda harus melengkapi data profile terlebih dahulu untuk mengakses kursus.")
                return redirect('profile')
        except UserMhs.DoesNotExist:
            return redirect('profile')

        return super().dispatch(request, *args, **kwargs)
    

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        try:
            mhs = UserMhs.objects.get(nim=user)
            is_student = True
        except UserMhs.DoesNotExist:
            mhs = None
            is_student = False

        if is_student:
            enrolled_participants = CourseParticipant.objects.filter(
                mahasiswa=mhs
            ).select_related('course')

            enrolled_course_ids = enrolled_participants.values_list('course_id', flat=True)

            my_courses_qs = Course.objects.filter(id__in=enrolled_course_ids)\
                .select_related('prodi', 'period')\
                .prefetch_related('coaches', 'agendas__materials')\
                .order_by('-created_at')

            # Ambil periode unik yang tersedia dari course yang diambil mahasiswa
            available_periods = list({c.period for c in my_courses_qs if c.period})
            available_periods.sort(key=lambda p: getattr(p, 'start_date', getattr(p, 'created_at', p.id)), reverse=True)

            # Logic Filter
            sel_period = self.request.GET.get('period', '')
            if sel_period:
                my_courses_qs = my_courses_qs.filter(period__id=sel_period)

            my_courses = my_courses_qs
            participant_map = {p.course_id: p for p in enrolled_participants}

            for course in my_courses:
                participant = participant_map.get(course.id)
                # Hitung total material via agendas (Course → CourseAgenda → CourseMaterial)
                total = CourseMaterial.objects.filter(
                    agenda__course=course
                ).count()
                if participant and total > 0:
                    completed = StudentMaterialProgress.objects.filter(
                        participant=participant,
                        is_completed=True
                    ).count()
                    course.progress = round((completed / total) * 100)
                else:
                    course.progress = 0

            context['my_courses'] = my_courses
            context['available_periods'] = available_periods
            context['sel_period'] = sel_period
        else:
            context['my_courses'] = []
            context['available_periods'] = []
            context['sel_period'] = ''

        context.update({
            "title": "Academy - Kursus Saya",
            "heading": "Daftar Mata Kuliah",
        })
        
        return context
    


class CoursePlayerView(StudentsRequiredMixin, AcademyView):
    template_name = "course_player.html"

    def get(self, request, course_uuid, material_id=None, assignment_id=None, *args, **kwargs):
        course = get_object_or_404(Course, uuid=course_uuid)
        sections = CourseAgenda.objects.filter(course=course).prefetch_related('materials', 'assignments', 'media_items__media_file')

        # === 1. LOGIK ACTIVE ITEM (BAWAAN ANDA) ===
        active_item = None
        active_type = None
        submission = None

        if material_id:
            active_item = get_object_or_404(CourseMaterial, id=material_id, agenda__course=course)
            active_type = 'material'
        elif assignment_id:
            active_item = get_object_or_404(CourseAssignment, id=assignment_id, agenda__course=course)
            active_type = 'assignment'
        else:
            first_material = CourseMaterial.objects.filter(
                agenda__course=course
            ).order_by('agenda__agenda_date', 'order').first()

            first_assignment = CourseAssignment.objects.filter(
                agenda__course=course
            ).order_by('agenda__agenda_date').first()

            if first_material and first_assignment:
                if first_material.agenda.agenda_date <= first_assignment.agenda.agenda_date:
                    active_item = first_material
                    active_type = 'material'
                else:
                    active_item = first_assignment
                    active_type = 'assignment'
            elif first_material:
                active_item = first_material
                active_type = 'material'
            elif first_assignment:
                active_item = first_assignment
                active_type = 'assignment'

        # === 2. AMBIL DATA PENDUKUNG LAINNYA ===
        announcements = CourseAnnouncement.objects.filter(course=course).order_by('-is_pinned', '-created_at')
        
        # [BARU] Ambil Data Kuis
        quizzes = CourseQuiz.objects.filter(course=course, is_published=True).order_by('start_time')

        completed_material_ids = []
        completed_assignment_ids = []
        attendance_report = [] 
        total_hadir = 0
        user_attendance_map = {} 
        my_group = None
        group_members = []

        # === 3. CEK PROGRESS USER (JIKA LOGIN) ===
        if request.user.is_authenticated:
            mhs_profile = UserMhs.objects.filter(nim=request.user).first()
            if mhs_profile:
                participant = CourseParticipant.objects.filter(course=course, mahasiswa=mhs_profile).first()
                if participant:
                    # Cek Materi Selesai
                    completed_material_ids = StudentMaterialProgress.objects.filter(
                        participant=participant, is_completed=True
                    ).values_list('material_id', flat=True)

                    # Cek Tugas Selesai
                    completed_assignment_ids = StudentAssignmentSubmission.objects.filter(
                        student=mhs_profile, assignment__agenda__course=course
                    ).values_list('assignment_id', flat=True)

                    if active_type == 'assignment':
                        submission = StudentAssignmentSubmission.objects.filter(
                            student=mhs_profile, assignment=active_item
                        ).first()
                    
                    # Cek Absensi
                    records = CourseAttendance.objects.filter(participant=participant)
                    for rec in records:
                        user_attendance_map[rec.agenda.id] = rec
                        if rec.status == 'present':
                            total_hadir += 1
                    
                    my_group_rel = CourseGroupMember.objects.filter(
                        participant=participant
                    ).select_related('group').first()
                    

                    if my_group_rel:
                        my_group = my_group_rel.group
                        group_members = my_group.members.select_related('participant__mahasiswa__nim').order_by('role', 'participant__mahasiswa__nim__first_name')
                        
                    for quiz in quizzes:
                        now = timezone.now()
                        is_done = StudentQuizAttempt.objects.filter(
                            quiz=quiz, 
                            participant=participant, 
                            finished_at__isnull=False
                        ).exists()

                        quiz.user_is_done = is_done

                        last_attempt = StudentQuizAttempt.objects.filter(
                            quiz=quiz, 
                            participant=participant, 
                            finished_at__isnull=False
                        ).order_by('-finished_at').first()
                        quiz.user_is_done = last_attempt is not None

                        if last_attempt:
                            quiz.user_is_done = True
                            quiz.last_attempt_id = last_attempt.id
                            quiz.user_score = last_attempt.total_score
                        else:
                            quiz.user_score = None

                        quiz.is_expired = now > quiz.end_time
                        quiz.is_not_started = now < quiz.start_time

        # === 4. SUSUN LAPORAN ABSENSI ===
        for agenda in sections:
            att_record = user_attendance_map.get(agenda.id)
            attendance_report.append({
                'agenda_title': agenda.title,
                'agenda_type': agenda.agenda_type,
                'agenda_date': agenda.agenda_date,
                'status': att_record.status if att_record else 'none',
                'check_in_time': att_record.check_in_time if att_record else None,
                'notes': att_record.notes if att_record else None,
                'created_at': att_record.created_at if att_record else None,
            })

        is_overdue = False
        if active_type == 'assignment':
             if timezone.now() > active_item.due_date:
                 is_overdue = True

        # === 5. KIRIM KE CONTEXT ===
        context = self.get_context_data(
            is_overdue=is_overdue,
            course=course,
            sections=sections,
            active_item=active_item,
            active_type=active_type,
            submission=submission,
            completed_material_ids=completed_material_ids,
            completed_assignment_ids=completed_assignment_ids,
            announcements=announcements,     
            attendance_report=attendance_report, 
            total_hadir=total_hadir,
            quizzes=quizzes,  # <--- JANGAN LUPA TAMBAHKAN INI
            my_group=my_group,          # Variabel ini sekarang aman karena sudah di-init di atas
            group_members=group_members
        )
        return self.render_to_response(context)

    def post(self, request, course_uuid, material_id=None, assignment_id=None, *args, **kwargs):
        course = get_object_or_404(Course, uuid=course_uuid)
        
        if not request.user.is_authenticated:
            return redirect('login')

        mhs_profile = get_object_or_404(UserMhs, nim=request.user)
        participant = get_object_or_404(CourseParticipant, course=course, mahasiswa=mhs_profile)

        if material_id:
            # ... (Material logic remains the same) ...
            material = get_object_or_404(CourseMaterial, id=material_id, agenda__course=course)
            progress, created = StudentMaterialProgress.objects.get_or_create(
                participant=participant, material=material
            )
            progress.is_completed = True
            progress.completed_at = timezone.now()
            progress.save()
            
            messages.success(request, 'Materi selesai dibaca dengan baik..!')
            return redirect('course-player-material', course_uuid=course.uuid, material_id=material_id)

        elif assignment_id:
            assignment = get_object_or_404(CourseAssignment, id=assignment_id, agenda__course=course)

            # Consolidated Deadline Check
            is_overdue = timezone.now() > assignment.due_date
            if is_overdue and not assignment.allow_late_submission:
                messages.error(request, 'Batas waktu pengumpulan sudah berakhir.')
                return redirect('course-player-assignment', course_uuid=course.uuid, assignment_id=assignment.id)
            
            # Input Retrieval
            link_input = request.POST.get('submitted_link')
            text_input = request.POST.get('submitted_text')

            # Validation for Link Input
            if not link_input:
                messages.error(request, 'Link tugas tidak boleh kosong!')
                return redirect('course-player-assignment', course_uuid=course.uuid, assignment_id=assignment.id)

            # Update or Create Submission
            submission, created = StudentAssignmentSubmission.objects.update_or_create(
                student=mhs_profile,
                assignment=assignment,
                defaults={
                    'submitted_link': link_input,
                    'submitted_text': text_input,
                    'updated_at': timezone.now()
                }
            )
        
            messages.success(request, 'Tugas berhasil dikumpulkan!')
            return redirect('course-player-assignment', course_uuid=course.uuid, assignment_id=assignment.id)

        return redirect('course-player', course_uuid=course.uuid)



# --- VIEW: HALAMAN COVER / PERSIAPAN UJIAN ---
class StudentQuizStartView(StudentsRequiredMixin, AcademyView):
    template_name = "students/quiz_start.html"

    def get(self, request, quiz_id, *args, **kwargs):
        quiz = get_object_or_404(CourseQuiz, id=quiz_id)
        
        if timezone.now() > quiz.end_time:
            messages.error(request, "Waktu ujian telah berakhir.")
            return redirect('course-player', course_uuid=quiz.course.uuid)
        # 1. Identifikasi Mahasiswa & Peserta Course
        mhs_profile = get_object_or_404(UserMhs, nim=request.user)
        participant = get_object_or_404(CourseParticipant, course=quiz.course, mahasiswa=mhs_profile)
        
        # 2. Cek apakah ada ujian yang BELUM disubmit (Status Running)
        active_attempt = StudentQuizAttempt.objects.filter(
            quiz=quiz, 
            participant=participant, 
            finished_at__isnull=True
        ).first()

        # Jika ada yang aktif, paksa redirect ke halaman pengerjaan
        if active_attempt:
            return redirect('student-quiz-take', attempt_id=active_attempt.id)

        # 3. Hitung jumlah percobaan yang sudah selesai
        existing_attempts = StudentQuizAttempt.objects.filter(
            quiz=quiz, 
            participant=participant, 
            finished_at__isnull=False
        ).count()

        can_start = True
        if existing_attempts >= quiz.max_attempts:
            can_start = False
            messages.warning(request, "Anda sudah menghabiskan batas maksimal percobaan untuk ujian ini.")

        return self.render_to_response(self.get_context_data(
            quiz=quiz,
            participant=participant,
            existing_attempts=existing_attempts,
            can_start=can_start
        ))

    def post(self, request, quiz_id, *args, **kwargs):
        quiz = get_object_or_404(CourseQuiz, id=quiz_id)
        mhs_profile = get_object_or_404(UserMhs, nim=request.user)
        participant = get_object_or_404(CourseParticipant, course=quiz.course, mahasiswa=mhs_profile)

        # Cek limit lagi untuk keamanan
        count = StudentQuizAttempt.objects.filter(quiz=quiz, participant=participant).count()
        if count >= quiz.max_attempts:
            return redirect('student-quiz-start', quiz_id=quiz.id)

        # Create Attempt Baru
        attempt = StudentQuizAttempt.objects.create(
            quiz=quiz,
            participant=participant
        )
        return redirect('student-quiz-take', attempt_id=attempt.id)


# --- VIEW: HALAMAN MENGERJAKAN SOAL (TIMER & SOAL) ---
class StudentQuizTakeView(StudentsRequiredMixin, AcademyView):
    template_name = "students/quiz_take.html"

    def get(self, request, attempt_id, *args, **kwargs):
        # 1. Validasi Attempt milik user yang login
        attempt = get_object_or_404(
            StudentQuizAttempt, 
            id=attempt_id, 
            participant__mahasiswa__nim=request.user
        )
        
        # 2. Jika sudah selesai, lempar ke result
        if attempt.finished_at:
            return redirect('student-quiz-result', attempt_id=attempt.id)
            
        quiz = attempt.quiz
        questions = quiz.questions.all().order_by('order')

        # 3. Hitung Sisa Waktu (Server Side Calculation)
        import datetime
        now = timezone.now()
        # Batas waktu = Waktu Mulai + Durasi Menit
        time_limit = attempt.started_at + datetime.timedelta(minutes=quiz.duration_minutes)
        remaining_seconds = (time_limit - now).total_seconds()

        # 4. Jika waktu minus, paksa submit
        if remaining_seconds <= 0:
            messages.warning(request, "Waktu ujian telah habis!")
            # Kita redirect ke view submit untuk memproses penutupan
            return redirect('student-quiz-submit', attempt_id=attempt.id)

        return self.render_to_response(self.get_context_data(
            attempt=attempt,
            quiz=quiz,
            questions=questions,
            remaining_seconds=int(remaining_seconds)
        ))


# --- VIEW: PROSES SUBMIT JAWABAN (Logic Penilaian) ---
class StudentQuizSubmitView(StudentsRequiredMixin, AcademyView):
    def get(self, request, attempt_id, *args, **kwargs):
        # Jika user akses GET (misal via URL langsung), tutup ujian jika waktu habis,
        # atau redirect ke result jika sudah selesai.
        attempt = get_object_or_404(
            StudentQuizAttempt, 
            id=attempt_id, 
            participant__mahasiswa__nim=request.user
        )
        if not attempt.finished_at:
             # Auto close mechanism (misal waktu habis)
             attempt.finished_at = timezone.now()
             attempt.save()
        return redirect('student-quiz-result', attempt_id=attempt.id)

    def post(self, request, attempt_id, *args, **kwargs):
        attempt = get_object_or_404(
            StudentQuizAttempt, 
            id=attempt_id, 
            participant__mahasiswa__nim=request.user
        )
        
        # Cegah submit ulang
        if attempt.finished_at:
            return redirect('student-quiz-result', attempt_id=attempt.id)

        quiz = attempt.quiz
        questions = quiz.questions.all()
        
        # --- 1. Simpan Jawaban ---
        for q in questions:
            input_name = f"question_{q.id}"
            
            # Case A: Pilihan Ganda
            if q.question_type == 'multiple_choice':
                selected_option_id = request.POST.get(input_name)
                if selected_option_id:
                    # Validasi opsi milik soal tersebut
                    option = QuizOption.objects.filter(id=selected_option_id, question=q).first()
                    if option:
                        StudentQuizAnswer.objects.update_or_create(
                            attempt=attempt,
                            question=q,
                            defaults={'selected_option': option, 'text_answer': None}
                        )
            
            # Case B: Essay
            elif q.question_type == 'essay':
                text_ans = request.POST.get(input_name)
                if text_ans:
                    StudentQuizAnswer.objects.update_or_create(
                        attempt=attempt,
                        question=q,
                        defaults={'text_answer': text_ans, 'selected_option': None}
                    )

        # --- 2. Auto Grading (Khusus PG) & Finalisasi ---
        attempt.finished_at = timezone.now()
        
        total_score = 0
        # Ambil semua jawaban di attempt ini
        answers = StudentQuizAnswer.objects.filter(attempt=attempt).select_related('question', 'selected_option')
        
        for ans in answers:
            # Logic Nilai: Jika PG dan Benar, ambil bobot soal
            if ans.question.question_type == 'multiple_choice':
                if ans.selected_option and ans.selected_option.is_correct:
                    ans.score_obtained = ans.question.score_weight
                else:
                    ans.score_obtained = 0
                ans.save() # Simpan nilai per soal
                total_score += ans.score_obtained
            
            # Essay score_obtained default 0, menunggu penilaian dosen
        
        attempt.total_score = total_score
        attempt.save()

        messages.success(request, "Jawaban berhasil dikirim. Terima kasih!")
        return redirect('student-quiz-result', attempt_id=attempt.id)

class StudentQuizResultView(StudentsRequiredMixin, AcademyView):
    template_name = "students/quiz_result.html"

    # === [TAMBAHAN BARU] ===
    # Method ini akan dijalankan sebelum halaman dirender
    def get(self, request, *args, **kwargs):
        attempt_id = kwargs.get('attempt_id')
        
        # 1. Ambil attempt dan pastikan milik user yang login
        attempt = get_object_or_404(
            StudentQuizAttempt, 
            id=attempt_id, 
            participant__mahasiswa__nim=request.user
        )

        # 2. SECURITY CHECK: Apakah ujian sudah selesai?
        if not attempt.finished_at:
            messages.warning(request, "Anda belum menyelesaikan ujian ini. Silakan selesaikan (Submit) terlebih dahulu.")
            # Redirect paksa ke halaman pengerjaan (Take Quiz)
            return redirect('student-quiz-take', attempt_id=attempt.id)
        
        # 3. Jika sudah selesai, lanjutkan ke proses render biasa (get_context_data)
        return super().get(request, *args, **kwargs)
    # =======================

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        attempt_id = self.kwargs.get('attempt_id') 
        
        # Ambil ulang attempt (atau bisa simpan di self.attempt saat di get() biar hemat query)
        attempt = get_object_or_404(
            StudentQuizAttempt, 
            id=attempt_id, 
            participant__mahasiswa__nim=self.request.user
        )

        # ... (sisa kode logic get_context_data Anda yang sebelumnya tetap sama) ...
        # 1. Ambil pertanyaan
        questions = attempt.quiz.questions.all().order_by('order')
        
        # 2. Ambil jawaban user
        user_answers = StudentQuizAnswer.objects.filter(attempt=attempt).select_related('selected_option')
        answer_map = {ans.question.id: ans for ans in user_answers}

        detailed_results = []
        total_correct = 0
        total_questions = questions.count()

        for q in questions:
            user_ans = answer_map.get(q.id)
            
            # Logic cari correct option
            if hasattr(q, 'options'):
                correct_option = q.options.filter(is_correct=True).first()
            else:
                correct_option = q.quizoption_set.filter(is_correct=True).first()

            is_correct = False
            user_selected_option = None
            user_text_answer = None
            score_obtained = 0

            if user_ans:
                user_selected_option = user_ans.selected_option
                user_text_answer = user_ans.text_answer
                score_obtained = user_ans.score_obtained
                
                if score_obtained > 0:
                    is_correct = True
                    total_correct += 1
            
            detailed_results.append({
                'question': q,
                'user_answer_obj': user_ans,
                'user_selected_option': user_selected_option,
                'user_text_answer': user_text_answer,
                'correct_option': correct_option,
                'is_correct': is_correct,
                'score': score_obtained
            })

        is_exam_closed = timezone.now() > attempt.quiz.end_time

        context.update({
            "title": "Hasil Kuis",
            "attempt": attempt,
            "quiz": attempt.quiz,
            "show_discussion": is_exam_closed,
            "course_uuid": attempt.quiz.course.uuid, 
            "detailed_results": detailed_results,
            "stats": {
                'total': total_questions,  
                'correct': total_correct, 
                'final_score': attempt.total_score
            }
        })
        return context

class StudentCourseGradesView(StudentsRequiredMixin, AcademyView):
    template_name = "students/student_course_grades.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        course_uuid = self.kwargs.get('course_uuid')
        course = get_object_or_404(Course, uuid=course_uuid)
        
        mhs_profile = get_object_or_404(UserMhs, nim=self.request.user)
        participant = get_object_or_404(CourseParticipant, course=course, mahasiswa=mhs_profile)

        # 1. Quizzes
        quizzes = CourseQuiz.objects.filter(course=course, is_published=True).order_by('start_time')
        quiz_data = []
        for q in quizzes:
            last_attempt = StudentQuizAttempt.objects.filter(
                quiz=q, participant=participant, finished_at__isnull=False
            ).order_by('-finished_at').first()
            quiz_data.append({
                'title': q.title,
                'duration': q.duration_minutes,
                'score': last_attempt.total_score if last_attempt else None,
                'date_taken': last_attempt.finished_at if last_attempt else None,
            })

        # 2. Assignments
        assignments = CourseAssignment.objects.filter(agenda__course=course, is_published=True).order_by('due_date')
        assignment_data = []
        for a in assignments:
            sub = StudentAssignmentSubmission.objects.filter(assignment=a, student=mhs_profile).first()
            assignment_data.append({
                'title': a.title,
                'due_date': a.due_date,
                'score': sub.score if sub and sub.score is not None else None,
                'submitted_at': sub.updated_at if sub else None,
            })

        context.update({
            "title": "Rekap Nilai",
            "heading": f"Tabel Nilai - {course.name}",
            "course": course,
            "quiz_data": quiz_data,
            "assignment_data": assignment_data,
        })
        return context

class StudentLibraryListView(StudentsRequiredMixin, AcademyView):
    template_name = "perpustakaan/student_library_list.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Ambil parameter dari URL untuk Search & Filter
        search_query = self.request.GET.get('q', '')
        category_filter = self.request.GET.get('category', '')
        
        # Query Dasar: Ambil semua buku, urutkan terbaru
        books = Book.objects.all().select_related('category').order_by('-created_at')

        # Logic Pencarian (Judul atau Penulis)
        if search_query:
            books = books.filter(
                Q(title__icontains=search_query) | 
                Q(author__icontains=search_query)
            )

        # Logic Filter Kategori
        if category_filter:
            books = books.filter(category__name=category_filter)

        context.update({
            "title": "Perpustakaan Digital",
            "books": books,
            "categories": BookCategory.objects.all().order_by('name'), # Untuk dropdown/pill filter
            "search_query": search_query,
            "active_category": category_filter,
        })
        return context

class StudentBookDetailView(LoginRequiredMixin, AcademyView):
    template_name = "perpustakaan/student_book_detail.html"

    def get_context_data(self, pk, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Ambil buku berdasarkan UUID (pk)
        book = get_object_or_404(Book, id=pk)
        
        # Rekomendasi: Buku lain dalam kategori yang sama (kecuali buku ini sendiri)
        related_books = Book.objects.filter(
            category=book.category
        ).exclude(id=pk).order_by('?')[:4] # Random 4 buku

        context.update({
            "title": book.title,
            "book": book,
            "related_books": related_books
        })
        return context
    

class CourseLeaderboardView(LoginRequiredMixin, AcademyView):
    template_name = "students/course_leaderboard.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        course_uuid = self.kwargs.get('course_uuid')
        course = get_object_or_404(Course, uuid=course_uuid)
        
        # 1. Hitung Total Items (Denominator)
        total_materials = CourseMaterial.objects.filter(agenda__course=course, is_published=True).count()
        total_assignments = CourseAssignment.objects.filter(agenda__course=course, is_published=True).count()
        total_agendas = CourseAgenda.objects.filter(course=course).count() 
        total_quizzes = CourseQuiz.objects.filter(course=course, is_published=True).count()
        total_items = total_materials + total_assignments + total_agendas + total_quizzes

        leaderboard_data = []
        
        # 2. Query Data Partisipan & Hitung Progress
        # select_related('mahasiswa__nim') sudah memuat data User (termasuk last_login)
        participants = CourseParticipant.objects.filter(course=course)\
            .select_related('mahasiswa__nim')\
            .annotate(
                count_materials=Count('material_progress', 
                    filter=Q(material_progress__is_completed=True), distinct=True),
                
                count_assignments=Count('mahasiswa__submissions', 
                    filter=Q(mahasiswa__submissions__assignment__agenda__course=course), distinct=True),
                
                count_attendance=Count('attendances', 
                    filter=Q(attendances__status__in=['present', 'sick', 'excused']), distinct=True),
                
                count_quizzes=Count('quiz_attempts__quiz', 
                    filter=Q(quiz_attempts__finished_at__isnull=False), distinct=True)
            )\
            .annotate(
                total_completed=F('count_materials') + F('count_assignments') + F('count_attendance') + F('count_quizzes')
            )\
            .order_by('-total_completed', 'mahasiswa__nim__first_name')

        # 3. Format Data
        for rank, p in enumerate(participants, 1):
            percent = 0
            if total_items > 0:
                percent = int((p.total_completed / total_items) * 100)
            
            if percent > 100: percent = 100
            
            leaderboard_data.append({
                'rank': rank,
                'name': p.mahasiswa.nim.first_name,
                'full_name': f"{p.mahasiswa.nim.first_name}",
                'username': p.mahasiswa.nim.username,
                'photo_url': p.mahasiswa.photo.url if p.mahasiswa.photo else None,
                'percent': percent,
                
                # [BARU] Tambahkan Last Login di sini
                'last_login': p.mahasiswa.nim.last_login, 

                'stats': {
                    'materials': p.count_materials,      
                    'assignments': p.count_assignments,
                    'attendance': p.count_attendance,
                    'quizzes': p.count_quizzes,
                    'total_user': p.total_completed
                },
                'is_me': p.mahasiswa.nim.username == self.request.user.username 
            })

        context['course'] = course
        context['leaderboard'] = leaderboard_data
        context['max_stats'] = {
            'materials': total_materials,
            'assignments': total_assignments,
            'attendance': total_agendas,
            'quizzes': total_quizzes,
            'total_items': total_items
        }
        
        return context